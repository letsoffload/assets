#!/bin/zsh
# OFF-4005 P3: run the BUILT server bundle in node:24.9-alpine pinned to 1 CPU.
# usage: server.sh start <srvdir> <outdir> | stop | wait
# Env is passed by NAME (-e VAR) from the lane's local-only .env.server (no secrets in it:
# lane DB, lane issuer, dummy AWS/Twilio/SendGrid keys pointed at 127.0.0.1:9).
set -u
NAME=off-4005-srv
NET=off-4005-net
LANE_ENV=${LANE_ENV:-/Users/nate/src/offload/_wt/offload/off-4005/.env.server}
TOOLS=/Users/nate/src/offload/rca-2026-10-30-alerts-oct29-30/fix/repro/P3/scripts
case "$1" in
start)
  SRV=$2; OUT=$3; mkdir -p $OUT
  docker network inspect $NET >/dev/null 2>&1 || docker network create $NET >/dev/null
  docker network inspect $NET --format '{{range .Containers}}{{.Name}} {{end}}' | grep -q off-4005-pg || docker network connect $NET off-4005-pg
  for v in $(grep -E '^[A-Z0-9_]+=' $LANE_ENV | cut -d= -f1); do export "$(grep -E "^$v=" $LANE_ENV | head -1)"; done
  export DB_HOST=off-4005-pg DB_PORT=5432 OSM_DB_HOST=off-4005-pg OSM_DB_PORT=5432 PORT=15011
  export NODE_ENV=production TZ=UTC NODE_OPTIONS=--max-old-space-size=3072 PROF_DIR=/prof
  envargs=()
  for v in $(grep -E '^[A-Z0-9_]+=' $LANE_ENV | cut -d= -f1) NODE_ENV TZ NODE_OPTIONS PROF_DIR; do envargs+=(-e $v); done
  docker rm -f $NAME >/dev/null 2>&1
  docker run -d --name $NAME --network $NET --cpus=${CPUS:-1} --memory=4g \
    -p 127.0.0.1:15011:15011 "${envargs[@]}" \
    -v $SRV:/app -v $TOOLS:/prof-tools:ro -v $OUT:/prof -w /app \
    node:24.9-alpine node --cpu-prof --cpu-prof-dir=/prof --require /prof-tools/preload.js main.js >/dev/null
  echo "started $NAME"
  ;;
wait)
  for i in $(seq 1 240); do
    c=$(curl -s -o /dev/null -w '%{http_code}' 127.0.0.1:15011/api/health 2>/dev/null)
    [ "$c" = 200 ] && { echo "ready after ${i}x0.5s"; exit 0; }
    docker ps --format '{{.Names}}' | grep -q "^$NAME$" || { echo "server container died"; docker logs --tail 40 $NAME 2>&1 | cut -c1-300; exit 1; }
    sleep 0.5
  done; echo "timeout"; exit 1
  ;;
stop)
  OUT=${2:-}
  docker kill -s TERM $NAME >/dev/null 2>&1
  for i in $(seq 1 60); do docker ps --format '{{.Names}}' | grep -q "^$NAME$" || break; sleep 0.5; done
  [ -n "$OUT" ] && docker logs $NAME > $OUT/server.log 2>&1
  docker rm -f $NAME >/dev/null 2>&1; echo "stopped"
  ;;
esac
