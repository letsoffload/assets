// OFF-4005 P3: submit 15 pending phase ops on ONE Project aggregate as the requester
// (project_planner, no approval authority), via POST /api/events/:phaseUuid/submit.
// usage: KEY_DIR=... node submit-pending.js <base> <phaseUuid> <newTypeId> <existingTypeIds,csv> <outfile>
const { mint } = require('./issuer');
const crypto = require('crypto');
const fs = require('fs');
const [base, phaseUuid, newType, existingCsv, outFile] = process.argv.slice(2);
const token = mint('lane|off-4005-req');
const existing = existingCsv.split(',');
const ops = [
  { eventType: 'PhaseStartSet', payload: { phaseUuid, startDate: '2026-11-10' } },
  { eventType: 'PhaseEndSet', payload: { phaseUuid, endDate: '2026-11-20' } },
  { eventType: 'PhaseDayScopeSet', payload: { phaseUuid, k: 0, note: 'Mobilize crane, set mats, pre-lift meeting 0600' } },
  ...existing.slice(0, 11).map((resourceTypeId, i) => ({ eventType: 'PhaseRequirementSet', payload: { phaseUuid, resourceTypeId, qty: 2 + (i % 4) } })),
  { eventType: 'PhaseRequirementSet', payload: { phaseUuid, resourceTypeId: newType, qty: 1, notes: 'added by request' } },
];
(async () => {
  const out = [];
  for (const op of ops) {
    const res = await fetch(`${base}/api/events/${phaseUuid}/submit`, {
      method: 'POST',
      headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json', 'x-client-id': 'off-4005-requester' },
      body: JSON.stringify({ aggregateType: 'Project', idempotencyKey: crypto.randomUUID(), state: 'pending', ...op }),
    });
    const body = await res.json().catch(() => ({}));
    out.push({ eventType: op.eventType, status: res.status, id: body.id ?? body.eventId, state: body.state, version: body.version, err: res.status >= 300 ? body : undefined });
  }
  fs.writeFileSync(outFile, JSON.stringify(out, null, 1));
  console.log(out.map((o) => `${o.eventType} ${o.status} id=${o.id} ${o.state} v${o.version}${o.err ? ' ' + JSON.stringify(o.err).slice(0, 200) : ''}`).join('\n'));
})();
