-- OFF-4005 P3 repro: lane DB only. Adds 3 dispatchers + 1 requester (project_planner,
-- REQUEST-only on schedule/crew, no approval authority) to the board-scale org,
-- with the same user->Organization grant the seed's backfillRrgGrants arm (a) mints.
BEGIN;
INSERT INTO "user"(email, name, auth0_id, organization_id, role, created_at, updated_at) VALUES
 ('board-scale+d1@example.test','Dana Dispatch1','lane|off-4005-d1',1,'dispatcher',NOW(),NOW()),
 ('board-scale+d2@example.test','Dale Dispatch2','lane|off-4005-d2',1,'dispatcher',NOW(),NOW()),
 ('board-scale+d3@example.test','Drew Dispatch3','lane|off-4005-d3',1,'dispatcher',NOW(),NOW()),
 ('board-scale+req@example.test','Riley Requester','lane|off-4005-req',1,'project_planner',NOW(),NOW());
INSERT INTO resource_role_grants
  (id, principal_kind, principal_id, scope_kind, scope_id, role_id,
   cascade_to_descendants, owner_org_id, organization_id, status,
   permissions, valid_from, created_at, updated_at, dispatch_origin_table, dispatch_origin_ref)
SELECT gen_random_uuid(), 'user', u.id, 'Organization', o.uuid, u.role, true,
       u.organization_id, u.organization_id, 'accepted', NULL, NOW(), NOW(), NOW(), NULL, NULL
  FROM "user" u JOIN organization o ON o.id = u.organization_id
 WHERE u.auth0_id LIKE 'lane|off-4005-%';
-- admin (seeded) is the approver: point nothing at Auth0; the lane issuer signs for 'seed|board-scale-admin'.
COMMIT;
SELECT id, email, role, auth0_id FROM "user" ORDER BY id;
