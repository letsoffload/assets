#!/bin/zsh
# OFF-4005 P3: one run = restore DB from template -> fresh 1-CPU server -> harness -> stop.
# usage: run.sh <srvdir> <outdir> <mode A|B> <laneDir>
set -u
SRV=$1; OUT=$2; MODE=$3; LANE=$4
T=/Users/nate/src/offload/rca-2026-10-30-alerts-oct29-30/fix/repro/P3/scripts
KEY_DIR=/private/tmp/claude-501/-Users-nate-src-offload/2a791e1d-9f61-4c7c-8952-d06e37dce8b6/scratchpad/keys
IDS=$(cat $T/../raw/event-ids.txt)
PHASE=add005cc-3274-499e-ba2a-b5a69ca2c27e
export PGPASSWORD=postgres
$T/server.sh stop >/dev/null
psql -h localhost -p 15443 -U postgres -d postgres -q -c "select pg_terminate_backend(pid) from pg_stat_activity where datname in ('25md','p3snap') and pid<>pg_backend_pid()" -c 'drop database "25md"' -c 'create database "25md" template p3snap' >/dev/null || { echo restore failed; exit 1; }
n=$(psql -h localhost -p 15443 -U postgres -d 25md -At -c "select count(*) from events where aggregate_id='$PHASE' and state='pending'")
echo "restored: pending on phase = $n"
mkdir -p $OUT
$T/server.sh start $SRV $OUT >/dev/null && $T/server.sh wait || exit 1
sleep 3   # let boot-time work (schedulers, pool warm) settle
docker stats off-4005-srv --format '{{json .}}' > $OUT/docker-stats.jsonl 2>/dev/null &
DS=$!
(cd $T && LANE_DIR=$LANE KEY_DIR=$KEY_DIR node harness.js --base http://127.0.0.1:15011 --mode $MODE --out $OUT --phase $PHASE --ids $IDS) | tee $OUT/harness-stdout.txt
kill $DS 2>/dev/null
$T/server.sh stop $OUT
psql -h localhost -p 15443 -U postgres -d 25md -At -c "select state, count(*) from events where aggregate_id='$PHASE' group by 1 order by 1" > $OUT/db-after.txt
