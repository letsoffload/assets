// OFF-4005 P3 repro preload (throwaway, never committed). Loaded with
// `node --require /prof-tools/preload.js main.js` inside the --cpus=1 container.
// Every 250 ms writes one JSON line to $PROF_DIR/samples.jsonl:
//   event-loop delay (p50/p99/max over the window), process CPU % (cpuUsage delta),
//   heap, and every Sequelize pool's size/using/waiting/available.
const fs = require('fs');
const path = require('path');
const { monitorEventLoopDelay } = require('perf_hooks');
const dir = process.env.PROF_DIR || '/prof';
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, 'clock.json'), JSON.stringify({
  wallMs: Date.now(), hrtimeNs: process.hrtime.bigint().toString(), pid: process.pid,
}));
const pools = [];
try {
  const cmPath = require.resolve('sequelize/lib/dialects/abstract/connection-manager', { paths: [process.cwd()] });
  const CM = require(cmPath);
  const Klass = CM.ConnectionManager || CM.default || CM;
  const orig = Klass.prototype.initPools;
  Klass.prototype.initPools = function patched(...a) {
    const r = orig.apply(this, a);
    pools.push(this);
    return r;
  };
} catch (e) {
  fs.writeFileSync(path.join(dir, 'preload-pool-error.txt'), String(e && e.stack));
}
const h = monitorEventLoopDelay({ resolution: 10 });
h.enable();
// Exact lag distribution for any window: a 20 ms drift ticker; every tick's lag
// (actual - expected) is counted, and lags over 25 ms are kept verbatim.
let lagTicks = 0; let lagBig = [];
let expected = Date.now() + 20;
const lagTimer = setInterval(() => {
  const now = Date.now(); const lag = Math.max(0, now - expected);
  lagTicks++; if (lag > 25) lagBig.push(lag);
  expected = now + 20;
}, 20);
lagTimer.unref();
const out = fs.openSync(path.join(dir, 'samples.jsonl'), 'a');
let lastCpu = process.cpuUsage();
let lastT = process.hrtime.bigint();
const timer = setInterval(() => {
  const now = process.hrtime.bigint();
  const cpu = process.cpuUsage();
  const wallUs = Number(now - lastT) / 1000;
  const cpuUs = (cpu.user - lastCpu.user) + (cpu.system - lastCpu.system);
  lastCpu = cpu; lastT = now;
  const rec = {
    t: Date.now(),
    eld_p50_ms: h.percentile(50) / 1e6, eld_p99_ms: h.percentile(99) / 1e6,
    eld_max_ms: h.max / 1e6, eld_n: h.count,
    cpu_pct: Math.round((cpuUs / wallUs) * 1000) / 10,
    lag_ticks: lagTicks, lag_big_ms: lagBig,
    heap_mb: Math.round(process.memoryUsage().heapUsed / 1048576),
    pools: pools.map((cm, i) => {
      const p = cm.pool || {};
      let name = i;
      try { name = (cm.sequelize && cm.sequelize.options && cm.sequelize.options.name) || `pool${i}`; } catch {}
      return { name, max: p.maxSize ?? (cm.config && cm.config.pool && cm.config.pool.max), size: p.size, using: p.using, waiting: p.waiting, available: p.available };
    }),
  };
  h.reset(); lagTicks = 0; lagBig = [];
  fs.writeSync(out, JSON.stringify(rec) + '\n');
}, 250);
timer.unref();
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => { try { fs.closeSync(out); } catch {} process.exit(0); });
}
