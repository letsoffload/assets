"""OFF-4005 P3: roll a run's cpuprofile (POST window only) up by area, and give
inclusive (synchronous-stack) time for app methods seen on the stack.
usage: python profile_rollup.py <rundir>..."""
import glob, json, os, sys
from collections import defaultdict
AREAS = [('sequelize', 'node_modules/sequelize'), ('pg driver', 'node_modules/pg'), ('sentry/otel', '@sentry'),
         ('sentry/otel', '@opentelemetry'), ('aws sdk', '@aws-sdk'), ('aws sdk', '@smithy'), ('zod', 'zod'),
         ('socket.io/engine', 'socket.io'), ('socket.io/engine', 'engine.io'), ('express/nest', '@nestjs'), ('express/nest', 'express'),
         ('pino', 'pino'), ('app code (main.js)', 'main.js'), ('node internals', 'node:')]
def area(cf):
    u = cf.get('url', ''); fn = cf.get('functionName', '')
    if fn in ('(garbage collector)',): return 'GC'
    if fn in ('(idle)',): return 'idle'
    if fn in ('(program)',): return 'program'
    for name, pat in AREAS:
        if pat in u: return name
    if not u: return 'native (writeBuffer/writev/...)'
    return 'other node_modules'
for d in sys.argv[1:]:
    h = json.load(open(os.path.join(d, 'harness.json'))); w0, w1 = h['post']['startWall'], h['post']['endWall']
    clock = json.load(open(os.path.join(d, 'clock.json'))); p = json.load(open(glob.glob(os.path.join(d, '*.cpuprofile'))[0]))
    nodes = {n['id']: n for n in p['nodes']}; parent = {}
    for n in p['nodes']:
        for c in n.get('children', []): parent[c] = n['id']
    hr0 = int(clock['hrtimeNs']) / 1000; t = p['startTime']
    by_area = defaultdict(float); incl = defaultdict(float); tot = 0
    for nid, dt in zip(p['samples'], p['timeDeltas']):
        t += dt; wall = clock['wallMs'] + (t - hr0) / 1000
        if not (w0 <= wall <= w1): continue
        tot += dt; by_area[area(nodes[nid]['callFrame'])] += dt
        seen = set(); x = nid
        while x is not None:
            cf = nodes[x]['callFrame']
            if 'main.js' in cf.get('url', '') and cf.get('functionName') and cf['functionName'] not in seen:
                seen.add(cf['functionName']); incl[cf['functionName']] += dt
            x = parent.get(x)
    out = {'run': os.path.basename(d), 'windowMs': round(tot / 1000),
           'byArea': sorted(((k, round(v / 1000), round(100 * v / tot, 1)) for k, v in by_area.items()), key=lambda r: -r[1]),
           'appInclusiveTop': sorted(((k, round(v / 1000), round(100 * v / tot, 1)) for k, v in incl.items()), key=lambda r: -r[1])[:20]}
    json.dump(out, open(os.path.join(d, 'profile-rollup.json'), 'w'), indent=1)
    print(out['run'], out['windowMs'], 'ms'); [print('   area', *r) for r in out['byArea'][:10]]; [print('   app ', *r) for r in out['appInclusiveTop'][:14]]
