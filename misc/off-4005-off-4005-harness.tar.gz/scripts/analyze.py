"""OFF-4005 P3: summarize one run directory -> summary.json (+ profile top table).

usage: python analyze.py <rundir> [<rundir> ...]
"""
import glob
import json
import os
import statistics
import sys
from collections import defaultdict


def jl(path):
    if not os.path.exists(path):
        return []
    with open(path) as f:
        return [json.loads(l) for l in f if l.strip()]


def pct(xs, p):
    if not xs:
        return None
    xs = sorted(xs)
    k = max(0, min(len(xs) - 1, int(round(p / 100 * (len(xs) - 1)))))
    return xs[k]


def analyze(d):
    h = json.load(open(os.path.join(d, 'harness.json')))
    post = h['post']
    w0, w1 = post['startWall'], post['endWall']
    t0wall = w0 - post['start']  # harness t0 in wall ms

    # per-event approve times (server pino `time` is wall ms)
    ev = defaultdict(dict)
    for line in open(os.path.join(d, 'server.log')):
        if '"approving event"' not in line and '"event approved"' not in line:
            continue
        try:
            r = json.loads(line)
        except Exception:
            continue
        eid = (r.get('input') or {}).get('eventId')
        ev[eid][r['msg']] = r['time']
    per_event = []
    for eid, v in sorted(ev.items(), key=lambda kv: kv[1].get('approving event', 0)):
        if 'approving event' in v and 'event approved' in v:
            per_event.append({
                'eventId': eid,
                'startRelPostS': round((v['approving event'] - w0) / 1000, 3),
                'sec': round((v['event approved'] - v['approving event']) / 1000, 3),
            })

    # frames / refreshes per client
    clients = {c['name']: c for c in h['clients']}
    flushes = jl(os.path.join(d, 'flushes.jsonl'))
    refresh_in_post = defaultdict(int)
    for f in flushes:
        if f['kind'] == 'decision' and post['start'] <= f['t'] <= post['end'] + 200:
            refresh_in_post[f['client']] += 1

    # requests
    reqs = jl(os.path.join(d, 'requests.jsonl'))
    status_lat = [r['end'] - r['start'] for r in reqs if 'resource-status' in r['url'] and r['start'] >= post['start'] and r['start'] <= post['end']]
    dd_lat = [r['end'] - r['start'] for r in reqs if 'dispatcher/data' in r['url'] and r['start'] >= post['start'] and r['start'] <= post['end']]
    pageload_status = [r['end'] - r['start'] for r in reqs if 'resource-status' in r['url'] and r['start'] < post['start']]
    codes = defaultdict(int)
    for r in reqs:
        codes[str(r.get('status'))] += 1

    # loop lag, cpu, pool during the POST window
    samples = [s for s in jl(os.path.join(d, 'samples.jsonl')) if w0 <= s['t'] <= w1 + 250]
    lags = []
    for s in samples:
        big = s.get('lag_big_ms', [])
        lags.extend(big)
        lags.extend([0] * max(0, s.get('lag_ticks', 0) - len(big)))
    cpu = [s['cpu_pct'] for s in samples]
    main_pool = [next((p for p in s['pools'] if p.get('max') == 20), None) for s in samples]
    main_pool = [p for p in main_pool if p]

    out = {
        'run': os.path.basename(d),
        'mode': h['meta']['mode'],
        'postMs': post['end'] - post['start'],
        'postStatus': post['status'],
        'approved': sum(1 for r in (post.get('results') or []) if r.get('status') == 'approved'),
        'errors': [r for r in (post.get('results') or []) if r.get('status') != 'approved'],
        'perEvent': per_event,
        'perEventMedianS': statistics.median([e['sec'] for e in per_event]) if per_event else None,
        'perEventMaxS': max([e['sec'] for e in per_event]) if per_event else None,
        'eventsOver1s': sum(1 for e in per_event if e['sec'] > 1),
        'clients': {
            n: {
                'frames': c['frames'], 'uniqueFrames': c['uniqueFrames'],
                'decisionRefreshes': c['refreshes'].get('decision', 0),
                'decisionRefreshesDuringPost': refresh_in_post.get(n, 0),
                'ownDropped': c['ownDropped'],
            } for n, c in clients.items() if n != 'approver'
        },
        'requests': {
            'total': len(reqs), 'codes': dict(codes),
            'statusDuringPost': len(status_lat),
            'statusLatencyMsMedian': statistics.median(status_lat) if status_lat else None,
            'statusLatencyMsMax': max(status_lat) if status_lat else None,
            'dispatcherDataLatencyMsMedian': statistics.median(dd_lat) if dd_lat else None,
            'pageloadStatusLatencyMsMedian': statistics.median(pageload_status) if pageload_status else None,
        },
        'loopLag': {
            'ticks': len(lags), 'p50': pct(lags, 50), 'p99': pct(lags, 99), 'max': max(lags) if lags else None,
            'monitorEld_p99_maxWindowMs': max([s['eld_p99_ms'] for s in samples], default=None),
            'monitorEld_max_ms': max([s['eld_max_ms'] for s in samples], default=None),
        },
        'cpu': {'samples': len(cpu), 'medianPct': statistics.median(cpu) if cpu else None, 'maxPct': max(cpu) if cpu else None},
        'pool': {
            'maxUsing': max([p['using'] for p in main_pool], default=None),
            'maxWaiting': max([p['waiting'] for p in main_pool], default=None),
            'maxSize': max([p['size'] for p in main_pool], default=None),
            'samplesWaiting': sum(1 for p in main_pool if p['waiting'] > 0),
        },
    }

    # cpu profile: self time per function inside the POST window
    profs = glob.glob(os.path.join(d, '*.cpuprofile'))
    clock = json.load(open(os.path.join(d, 'clock.json'))) if os.path.exists(os.path.join(d, 'clock.json')) else None
    if profs and clock:
        p = json.load(open(profs[0]))
        nodes = {n['id']: n for n in p['nodes']}
        t = p['startTime']  # us, CLOCK_MONOTONIC (same base as hrtime)
        hr0_us = int(clock['hrtimeNs']) / 1000
        self_us = defaultdict(float)
        total = 0.0
        for nid, dt in zip(p['samples'], p['timeDeltas']):
            t += dt
            wall = clock['wallMs'] + (t - hr0_us) / 1000
            if not (w0 <= wall <= w1):
                continue
            n = nodes[nid]
            cf = n['callFrame']
            url = cf.get('url', '').replace('file:///app/', '')
            key = f"{cf.get('functionName') or '(anonymous)'} {url.split('/node_modules/')[-1]}:{cf.get('lineNumber', -1) + 1}"
            self_us[key] += dt
            total += dt
        top = sorted(self_us.items(), key=lambda kv: -kv[1])[:20]
        out['profile'] = {
            'file': os.path.basename(profs[0]), 'windowSampledMs': round(total / 1000),
            'top20': [{'fn': k, 'selfMs': round(v / 1000, 1), 'pct': round(100 * v / total, 1) if total else 0} for k, v in top],
        }
    json.dump(out, open(os.path.join(d, 'summary.json'), 'w'), indent=1)
    return out


if __name__ == '__main__':
    for d in sys.argv[1:]:
        o = analyze(d)
        print(json.dumps({k: o[k] for k in ['run', 'mode', 'postMs', 'approved', 'perEventMedianS', 'perEventMaxS', 'eventsOver1s']}),
              {n: (c['frames'], c['decisionRefreshesDuringPost']) for n, c in o['clients'].items()}, o['loopLag'], o['cpu'], o['pool'])
