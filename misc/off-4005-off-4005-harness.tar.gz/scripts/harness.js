// OFF-4005 P3 repro harness (uncommitted; lives in the RCA folder, not the repo).
//
// Mode A: 3 dispatcher sockets in the org room + 1 same-org socket that also joins
// `aggregate:<phase uuid>` (the requester, on the project page). Each socket runs the
// REAL logic of libs/client/src/features/event-history/useRequestDecisionUpdates.ts:
//   - PROJECTION_UPDATED with payload.requestState only
//   - drop own frame (payload.originatingClientId === my client id)
//   - 'pending' -> pending-queue refresh only; anything else marks `decided`
//   - 150 ms TRAILING debounce (clearTimeout + setTimeout on every frame)
//   - flush: decided -> invalidateDecisionEffects (the board's active queries:
//     4 x GET /resource-status/current?asOf=<org today>&type=..., GET /dispatcher/data
//     with the board's default 3-day org window, GET /events/pending)
// React Query 5.90 semantics: invalidate refetches with cancelRefetch:true, but none of
// these queryFns consume the AbortSignal, so the in-flight HTTP request is NOT aborted:
// a new request is simply issued (we do the same, never aborting). Browsers send
// If-None-Match on repeat GETs, so we keep and send each URL's ETag.
// The approver (no socket) POSTs /api/events/approve once, then (mode A) runs its own
// onSuccess refresh, like the deciding tab.
// Mode B: no sockets, no refreshes: the POST alone.
const { io } = require(require.resolve('socket.io-client', { paths: [process.env.LANE_DIR || process.cwd()] }));
const fs = require('fs');
const path = require('path');
const { mint } = require('./issuer');

const arg = (k, d) => { const i = process.argv.indexOf(`--${k}`); return i > 0 ? process.argv[i + 1] : d; };
const BASE = arg('base', 'http://127.0.0.1:15011');
const MODE = arg('mode', 'A');
const OUT = arg('out');
const PHASE = arg('phase');
const IDS = arg('ids').split(',').map(Number);
const TZ = 'America/Chicago';
const QUIET_MS = Number(arg('quiet-ms', 4000));
const MAX_MS = Number(arg('max-ms', 240000));
fs.mkdirSync(OUT, { recursive: true });

const t0 = Date.now();
const rel = () => Date.now() - t0;
const reqLog = [];
const frameLog = [];
const flushLog = [];
let inflight = 0;
let lastActivity = Date.now();

function orgDay(offsetDays) {
  const now = new Date(Date.now() + offsetDays * 86400000);
  return new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
}
function orgDayStartIso(day) {
  // UTC instant of 00:00 on `day` in TZ.
  const [y, m, d] = day.split('-').map(Number);
  let guess = Date.UTC(y, m - 1, d, 5, 0, 0);
  for (let i = 0; i < 3; i++) {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: TZ, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })
      .formatToParts(new Date(guess)).map((p) => [p.type, p.value]));
    const local = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute);
    guess -= local - Date.UTC(y, m - 1, d, 0, 0);
  }
  return new Date(guess).toISOString();
}
const TODAY = orgDay(0);
const BOARD = { startDate: orgDayStartIso(orgDay(-1)), endDate: orgDayStartIso(orgDay(2)) };
const STATUS_URLS = ['truck', 'trailer', 'equipment', 'person'].map((type) => `/api/resource-status/current?asOf=${TODAY}&type=${type}`);
const DECISION_URLS = [...STATUS_URLS, `/api/dispatcher/data?startDate=${encodeURIComponent(BOARD.startDate)}&endDate=${encodeURIComponent(BOARD.endDate)}`, '/api/events/pending'];
const PENDING_URLS = ['/api/events/pending'];

// v2 (12:40 EDT): raw node:http, not fetch(). Per the Fetch spec, undici's fetch()
// turns a script-set If-None-Match into cache mode no-store and appends
// `Cache-Control: no-cache`, which makes Express's fresh() answer 200 every time.
// A browser's HTTP cache adds If-None-Match itself (no no-cache), so prod saw 304s.
// Each browser tab gets its own keep-alive agent with no socket cap (ALB -> target).
const http = require('http');
function get(client, url) {
  inflight++; lastActivity = Date.now();
  const rec = { client: client.name, url: url.split('?')[0] + (url.includes('type=') ? `?type=${url.split('type=')[1]}` : ''), start: rel() };
  if (!client.agent) client.agent = new http.Agent({ keepAlive: true, maxSockets: Infinity });
  const headers = { authorization: `Bearer ${client.token}`, 'x-client-id': client.clientId, 'accept-encoding': 'gzip, deflate, br' };
  if (client.etags[url]) headers['if-none-match'] = client.etags[url];
  return new Promise((resolve) => {
    const done = () => { rec.end = rel(); reqLog.push(rec); inflight--; lastActivity = Date.now(); resolve(); };
    const req = http.get(BASE + url, { headers, agent: client.agent }, (res) => {
      let bytes = 0;
      res.on('data', (c) => { bytes += c.length; });
      res.on('end', () => {
        const et = res.headers.etag; if (et) client.etags[url] = et;
        rec.status = res.statusCode; rec.bytes = bytes; done();
      });
    });
    req.on('error', (e) => { rec.status = 'ERR'; rec.err = String(e.message || e); done(); });
  });
}
function refresh(client, kind) {
  client.refreshes[kind] = (client.refreshes[kind] || 0) + 1;
  flushLog.push({ client: client.name, kind, t: rel() });
  const urls = kind === 'decision' ? DECISION_URLS : PENDING_URLS;
  return Promise.all(urls.map((u) => get(client, u)));
}

function makeClient(name, sub, joinAggregate) {
  const c = { name, sub, token: mint(sub), clientId: `off-4005-${name}-${Math.random().toString(36).slice(2, 8)}`, etags: {}, refreshes: {}, frames: 0, ownDropped: 0, decidedFrames: 0, pendingFrames: 0, seen: new Map() };
  return new Promise((resolve, reject) => {
    const s = io(BASE, { reconnection: false, transports: ['websocket'], auth: { token: `Bearer ${c.token}` } });
    c.socket = s;
    // --- the hook, verbatim logic ---
    let timer = null; let decided = false;
    const flush = () => { timer = null; if (decided) refresh(c, 'decision'); else refresh(c, 'pending'); decided = false; };
    s.on('message', (message) => {
      if (!message || message.type !== 'projection.updated') return;
      const payload = message.payload;
      if (!payload?.requestState) return;
      c.frames++; lastActivity = Date.now();
      const key = `${payload.aggregateId}@${payload.version}`;
      c.seen.set(key, (c.seen.get(key) || 0) + 1);
      frameLog.push({ client: name, t: rel(), aggregateId: payload.aggregateId, version: payload.version, eventType: payload.eventType, requestState: payload.requestState, copy: c.seen.get(key) });
      if (payload.originatingClientId && payload.originatingClientId === c.clientId) { c.ownDropped++; return; }
      if (payload.requestState !== 'pending') { decided = true; c.decidedFrames++; } else c.pendingFrames++;
      if (timer) clearTimeout(timer);
      timer = setTimeout(flush, 150);
    });
    s.on('connect', () => {
      if (joinAggregate) s.emit('subscribe-projection', { aggregateType: 'Project', aggregateId: PHASE });
      resolve(c);
    });
    s.on('connect_error', (e) => reject(new Error(`${name} connect_error ${e.message}`)));
  });
}

(async () => {
  const meta = { mode: MODE, base: BASE, phase: PHASE, ids: IDS, today: TODAY, board: BOARD, startedAt: new Date(t0).toISOString() };
  const clients = [];
  if (MODE === 'A') {
    clients.push(await makeClient('d1', 'lane|off-4005-d1', false));
    clients.push(await makeClient('d2', 'lane|off-4005-d2', false));
    clients.push(await makeClient('d3', 'lane|off-4005-d3', false));
    clients.push(await makeClient('viewer', 'lane|off-4005-req', true));
    // page load: every client fetches its board once (primes ETags), then quiet.
    await Promise.all(clients.map((c) => refresh(c, 'pageload')));
    await new Promise((r) => setTimeout(r, 2000));
  }
  const approver = { name: 'approver', token: mint('seed|board-scale-admin'), clientId: 'off-4005-approver', etags: {}, refreshes: {} };
  const post = { start: rel(), startWall: Date.now() };
  lastActivity = Date.now();
  inflight++;
  const res = await fetch(`${BASE}/api/events/approve`, {
    method: 'POST',
    headers: { authorization: `Bearer ${approver.token}`, 'content-type': 'application/json', 'x-client-id': approver.clientId },
    body: JSON.stringify({ eventIds: IDS }),
  });
  inflight--;
  post.end = rel(); post.endWall = Date.now(); post.status = res.status;
  const body = await res.json().catch(() => null);
  post.results = Array.isArray(body) ? body.map((r) => ({ eventId: r.eventId, status: r.status, code: r.code, error: r.error })) : body;
  if (MODE === 'A') refresh(approver, 'decision-own');
  // settle: wait until nothing in flight and QUIET_MS without frames or requests.
  const deadline = Date.now() + MAX_MS;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 200));
    if (inflight === 0 && Date.now() - lastActivity > QUIET_MS) break;
  }
  meta.settledAt = rel();
  for (const c of clients) c.socket.close();
  const summary = {
    meta, post,
    clients: [...clients, approver].map((c) => ({
      name: c.name, frames: c.frames ?? 0, uniqueFrames: c.seen ? c.seen.size : 0, ownDropped: c.ownDropped ?? 0,
      decidedFrames: c.decidedFrames ?? 0, pendingFrames: c.pendingFrames ?? 0, refreshes: c.refreshes,
    })),
    requests: { total: reqLog.length, duringPost: reqLog.filter((r) => r.start >= post.start && r.start <= post.end).length },
  };
  fs.writeFileSync(path.join(OUT, 'harness.json'), JSON.stringify(summary, null, 1));
  fs.writeFileSync(path.join(OUT, 'requests.jsonl'), reqLog.map((r) => JSON.stringify(r)).join('\n') + '\n');
  fs.writeFileSync(path.join(OUT, 'frames.jsonl'), frameLog.map((r) => JSON.stringify(r)).join('\n') + '\n');
  fs.writeFileSync(path.join(OUT, 'flushes.jsonl'), flushLog.map((r) => JSON.stringify(r)).join('\n') + '\n');
  console.log(JSON.stringify({ mode: MODE, postMs: post.end - post.start, status: post.status, approved: Array.isArray(body) ? body.filter((r) => r.status === 'approved').length : null, clients: summary.clients.map((c) => `${c.name}:f${c.frames}/u${c.uniqueFrames} r${JSON.stringify(c.refreshes)}`) }));
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
