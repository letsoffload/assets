// OFF-4005 P3 repro: throwaway local OIDC-ish issuer for the lane server only.
// Serves /.well-known/jwks.json; `node issuer.js mint <sub>` prints a token to stdout
// (used in-process by the harness, never written to the repro folder).
// Key lives in KEY_DIR (session scratchpad), not in the repro folder.
const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const path = require('path');
const KEY_DIR = process.env.KEY_DIR;
const ISS = process.env.LANE_ISS || 'http://host.docker.internal:15391/';
const AUD = process.env.LANE_AUD || 'https://off-4005.lane/api';
const PORT = Number(process.env.ISSUER_PORT || 15391);
const KID = 'off-4005-lane';
function keys() {
  const p = path.join(KEY_DIR, 'lane-issuer.pem');
  if (!fs.existsSync(p)) {
    const { privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
    fs.writeFileSync(p, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  }
  const priv = crypto.createPrivateKey(fs.readFileSync(p));
  return { priv, pub: crypto.createPublicKey(priv) };
}
const b64u = (b) => Buffer.from(b).toString('base64url');
function mint(sub, ttlSec = 6 * 3600) {
  const { priv } = keys();
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT', kid: KID }));
  const p = b64u(JSON.stringify({ iss: ISS, aud: AUD, sub, iat: now, exp: now + ttlSec }));
  const sig = crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), priv);
  return `${h}.${p}.${b64u(sig)}`;
}
module.exports = { mint };
if (require.main === module) {
  if (process.argv[2] === 'mint') { process.stdout.write(mint(process.argv[3])); process.exit(0); }
  const { pub } = keys();
  const jwk = { ...pub.export({ format: 'jwk' }), kid: KID, use: 'sig', alg: 'RS256' };
  http.createServer((req, res) => {
    if (req.url.startsWith('/.well-known/jwks.json')) {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ keys: [jwk] }));
    }
    res.writeHead(404); res.end();
  }).listen(PORT, '127.0.0.1', () => console.log(`lane issuer on 127.0.0.1:${PORT} iss=${ISS}`));
}
