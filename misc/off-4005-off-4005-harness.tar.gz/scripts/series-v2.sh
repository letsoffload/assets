#!/bin/zsh
P3=/Users/nate/src/offload/rca-2026-10-30-alerts-oct29-30/fix/repro/P3
S=/private/tmp/claude-501/-Users-nate-src-offload/2a791e1d-9f61-4c7c-8952-d06e37dce8b6/scratchpad
B=/Users/nate/src/offload/_wt/offload/off-4005
PR=/Users/nate/src/offload/_wt/offload/off-4005-pr1697
one() { # name cpus srv mode lane
  echo "== $1 $(date +%T) load=$(sysctl -n vm.loadavg)"
  CPUS=$2 $P3/scripts/run.sh $3 $P3/raw/$1 $4 $5 2>&1 | grep -v "^ready\|^stopped\|^restored" | cut -c1-230
}
for r in 1 2 3; do one base-cpu1-A$r 1 $S/srv-base A $B; one base-cpu1-B$r 1 $S/srv-base B $B; done
for r in 1 2 3; do one pr1697-cpu1-A$r 1 $S/srv-pr1697 A $PR; done
for r in 1 2 3; do one base-cpu033-A$r 0.33 $S/srv-base A $B; one base-cpu033-B$r 0.33 $S/srv-base B $B; done
for r in 1 2 3; do one pr1697-cpu033-A$r 0.33 $S/srv-pr1697 A $PR; done
echo SERIES-DONE
