"""OFF-4005 P3 AFTER: requestState frames per client per room copy, per run.

The harness records each received frame with `copy` = 1 for the first copy of an
(aggregate, version) and 2 for the second (the viewer is in the org room AND the
aggregate room). usage: python frames_per_room.py <rundir> [...]
"""
import json, os, sys
from collections import Counter
out = {}
for d in sys.argv[1:]:
    c = Counter()
    for line in open(os.path.join(d, 'frames.jsonl')):
        f = json.loads(line)
        if f.get('requestState'):
            c[(f['client'], f.get('copy', 1))] += 1
    out[os.path.basename(d)] = {f'{k[0]}#copy{k[1]}': v for k, v in sorted(c.items())}
print(json.dumps(out, indent=1))
