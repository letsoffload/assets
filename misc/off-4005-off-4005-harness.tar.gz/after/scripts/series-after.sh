#!/bin/zsh
# OFF-4005 P3 AFTER: head (fix c396d2fda) A runs x3 at --cpus=1 and x3 at --cpus=0.33,
# same run.sh / snapshot / harness as the repro's base series (../../scripts/series-v2.sh).
P3=/Users/nate/src/offload/rca-2026-10-30-alerts-oct29-30/fix/repro/P3
S=/private/tmp/claude-501/-Users-nate-src-offload/2a791e1d-9f61-4c7c-8952-d06e37dce8b6/scratchpad
B=/Users/nate/src/offload/_wt/offload/off-4005
one() { # name cpus srv mode lane
  echo "== $1 $(date +%T) load=$(sysctl -n vm.loadavg)"
  CPUS=$2 $P3/scripts/run.sh $3 $P3/after/raw/$1 $4 $5 2>&1 | grep -v "^ready\|^stopped\|^restored" | cut -c1-230
}
for r in 1 2 3; do one head-cpu1-A$r 1 $S/srv-head A $B; done
for r in 1 2 3; do one head-cpu033-A$r 0.33 $S/srv-head A $B; done
echo SERIES-DONE
