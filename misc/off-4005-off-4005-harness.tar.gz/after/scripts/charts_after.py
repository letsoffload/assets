"""OFF-4005 P3 AFTER: base (repro, before) vs head (fix c396d2fda, after) -> table.json + PNG charts.
Copy of ../../scripts/charts.py with the arms renamed; the base runs are symlinked into after/raw.

usage: python charts.py <raw dir> <charts dir>
"""
import glob
import json
import os
import statistics
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402

RAW, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
INK, MUTED, GRID = '#1f2328', '#6e7781', '#d0d7de'
C_BASE, C_PR, C_B = '#0969da', '#1a7f37', '#8c959f'
plt.rcParams.update({'font.size': 10, 'axes.edgecolor': GRID, 'axes.labelcolor': INK, 'xtick.color': MUTED,
                     'ytick.color': MUTED, 'axes.spines.top': False, 'axes.spines.right': False})


def load(prefix):
    runs = []
    for d in sorted(glob.glob(os.path.join(RAW, prefix + '*'))):
        p = os.path.join(d, 'summary.json')
        if os.path.exists(p):
            runs.append(json.load(open(p)))
    return runs


def med(xs):
    xs = [x for x in xs if x is not None]
    return statistics.median(xs) if xs else None


groups = {}
for lane in ['base', 'head']:
    for cpu in ['cpu1', 'cpu05', 'cpu033']:
        for mode in ['A', 'B']:
            runs = load(f'{lane}-{cpu}-{mode}')
            if not runs:
                continue
            groups[f'{lane}-{cpu}-{mode}'] = {
                'n': len(runs),
                'runs': [r['run'] for r in runs],
                'postMs': [r['postMs'] for r in runs],
                'postMsMedian': med([r['postMs'] for r in runs]),
                'approved': [r['approved'] for r in runs],
                'perEventMedianS': med([r['perEventMedianS'] for r in runs]),
                'perEventMaxS': [r['perEventMaxS'] for r in runs],
                'eventsOver1s': [r['eventsOver1s'] for r in runs],
                'refreshesPerClientMedian': med([statistics.median([c['decisionRefreshes'] for c in r['clients'].values()]) for r in runs if r['clients']]) if mode == 'A' else 0,
                'refreshesPerClient': [{n: c['decisionRefreshes'] for n, c in r['clients'].items()} for r in runs],
                'framesPerClient': [{n: (c['frames'], c['uniqueFrames']) for n, c in r['clients'].items()} for r in runs],
                'lagP99Ms': [r['loopLag']['p99'] for r in runs],
                'lagP99MsMedian': med([r['loopLag']['p99'] for r in runs]),
                'lagMaxMs': [r['loopLag']['max'] for r in runs],
                'cpuMedianPct': med([r['cpu']['medianPct'] for r in runs]),
                'poolMaxWaiting': [r['pool']['maxWaiting'] for r in runs],
                'poolMaxUsing': [r['pool']['maxUsing'] for r in runs],
                'statusLatencyMsMedian': med([r['requests']['statusLatencyMsMedian'] for r in runs]),
            }
json.dump(groups, open(os.path.join(OUT, 'table.json'), 'w'), indent=1)


def median_run(key):
    runs = load(key)
    if not runs:
        return None
    runs = sorted(runs, key=lambda r: r['postMs'])
    return runs[len(runs) // 2]


# 1. per-event time, median run of each arm, base vs #1697 (+ B), per CPU level
for cpu, label in [('cpu1', '--cpus=1 (runbook spec)'), ('cpu033', '--cpus=0.33 (sensitivity: idle per-event ~ prod)')]:
    arms = [(f'base-{cpu}-A', 'base (before), with clients', C_BASE, 'o'), (f'head-{cpu}-A', 'fix head (after), with clients', C_PR, 's'),
            (f'base-{cpu}-B', 'base, no clients', C_B, '^')]
    arms = [(k, l, c, m, median_run(k)) for k, l, c, m in arms]
    arms = [a for a in arms if a[4]]
    if not arms:
        continue
    fig, ax = plt.subplots(figsize=(9, 4.2))
    for k, l, c, m, r in arms:
        xs = [e['startRelPostS'] for e in r['perEvent']]
        ys = [e['sec'] for e in r['perEvent']]
        ax.plot(range(1, len(ys) + 1), ys, marker=m, color=c, lw=1.6, ms=5, label=f"{l} ({r['run']}, POST {r['postMs']/1000:.1f} s)")
    ax.set_xlabel('event in the bulk approve (approval order, 1..15)')
    ax.set_ylabel('approving -> approved (s)')
    ax.set_title(f'Per-event approve time, median-wall run per arm, {label}', color=INK, fontsize=11, loc='left')
    ax.set_xticks(range(1, 16))
    ax.grid(axis='y', color=GRID, lw=0.6)
    ax.legend(frameon=False, fontsize=8.5)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, f'per-event-{cpu}.png'), dpi=160)
    plt.close(fig)

# 2. refreshes per client (median of runs), arms side by side
arms = [k for k in groups if k.endswith('-A')]
if arms:
    fig, ax = plt.subplots(figsize=(9, 3.8))
    clients = ['d1', 'd2', 'd3', 'viewer']
    w = 0.8 / len(arms)
    colors = {'base-cpu1-A': '#54aeff', 'head-cpu1-A': '#4ac26b', 'base-cpu033-A': '#0a3069', 'head-cpu033-A': '#116329'}
    for i, k in enumerate(arms):
        vals = [statistics.median([r.get(c, 0) for r in groups[k]['refreshesPerClient']]) for c in clients]
        bars = ax.bar([j + i * w for j in range(len(clients))], vals, w, label=k, color=colors.get(k, MUTED))
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.15, f'{v:g}', ha='center', fontsize=8, color=INK)
    ax.axhline(15, color='#cf222e', lw=1, ls='--')
    ax.text(len(clients) - 0.2, 14.3, 'prod-shape claim: 15 (one per frame)', color='#cf222e', fontsize=8, ha='right')
    ax.set_xticks([j + w * (len(arms) - 1) / 2 for j in range(len(clients))])
    ax.set_xticklabels(['dispatcher 1', 'dispatcher 2', 'dispatcher 3', 'aggregate viewer'])
    ax.set_ylabel('decision refreshes (median of 3)')
    ax.set_ylim(0, 20)
    ax.set_title('Full refreshes per client for one 15-event bulk approve, before vs after', color=INK, fontsize=11, loc='left')
    ax.legend(frameon=False, fontsize=8, ncol=5, loc='upper left')
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, 'refreshes-per-client.png'), dpi=160)
    plt.close(fig)

# 3. loop delay timeline (median-wall run per arm)
for cpu in ['cpu1', 'cpu033']:
    keys = [(f'base-{cpu}-A', C_BASE), (f'head-{cpu}-A', C_PR), (f'base-{cpu}-B', C_B)]
    fig, ax = plt.subplots(figsize=(9, 3.8))
    plotted = False
    for k, c in keys:
        r = median_run(k)
        if not r:
            continue
        d = os.path.join(RAW, r['run'])
        h = json.load(open(os.path.join(d, 'harness.json')))
        w0, w1 = h['post']['startWall'], h['post']['endWall']
        xs, ys = [], []
        for line in open(os.path.join(d, 'samples.jsonl')):
            s = json.loads(line)
            if w0 - 2000 <= s['t'] <= w1 + 2000:
                xs.append((s['t'] - w0) / 1000)
                ys.append(max(s.get('lag_big_ms') or [0]))
        ax.plot(xs, ys, color=c, lw=1.3, label=f"{k} ({r['run']}, POST ends {(w1 - w0)/1000:.1f} s)")
        plotted = True
    if not plotted:
        plt.close(fig)
        continue
    ax.axhline(1000, color='#cf222e', lw=1, ls='--')
    ax.text(0, 1020, 'C4 threshold 1 s', color='#cf222e', fontsize=8)
    ax.set_xlabel('seconds since POST /events/approve started')
    ax.set_ylabel('worst loop lag per 250 ms (ms)')
    ax.set_title(f'Event-loop lag during the bulk approve ({cpu})', color=INK, fontsize=11, loc='left')
    ax.grid(axis='y', color=GRID, lw=0.6)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, f'loop-lag-{cpu}.png'), dpi=160)
    plt.close(fig)

# 4. profile top-20 table as an image (median-wall base A run at cpus=1)
for key in ['head-cpu1-A', 'head-cpu033-A']:
    r = median_run(key)
    if not r or 'profile' not in r:
        continue
    rows = r['profile']['top20']
    fig, ax = plt.subplots(figsize=(11, 0.32 * len(rows) + 1.0))
    ax.axis('off')
    cell = [[str(i + 1), f"{x['selfMs']:.0f}", f"{x['pct']:.1f}%", x['fn'][:110]] for i, x in enumerate(rows)]
    t = ax.table(cellText=cell, colLabels=['#', 'self ms', 'share', 'function  file:line'], loc='upper left',
                 colLoc='left', cellLoc='left', colWidths=[0.04, 0.08, 0.07, 0.81])
    t.auto_set_font_size(False)
    t.set_fontsize(8)
    for (i, j), c in t.get_celld().items():
        c.set_edgecolor(GRID)
        if i == 0:
            c.set_text_props(weight='bold')
    ax.set_title(f"CPU profile self time inside the POST window, {r['run']} ({r['profile']['windowSampledMs']} ms sampled)",
                 color=INK, fontsize=10, loc='left')
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, f'profile-top20-{key}.png'), dpi=160)
    plt.close(fig)
print(json.dumps({k: {kk: v[kk] for kk in ['n', 'postMsMedian', 'perEventMedianS', 'refreshesPerClientMedian', 'lagP99MsMedian', 'cpuMedianPct', 'poolMaxWaiting', 'eventsOver1s']} for k, v in groups.items()}, indent=0))
